function cosineSimilarity(
  a: number[],
  b: number[]
): number {
  let dot = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }

  return (
    dot /
    (Math.sqrt(normA) *
      Math.sqrt(normB) +
      1e-8)
  );
}

function buildPseudoAttention(
  embeddings: number[][]
): number[][] {
  const seqLen = embeddings.length;

  const matrix = Array.from(
    { length: seqLen },
    () => Array(seqLen).fill(0)
  );

  for (let i = 0; i < seqLen; i++) {
    let rowSum = 0;

    for (let j = 0; j < seqLen; j++) {
      const score = Math.max(
        0,
        cosineSimilarity(
          embeddings[i],
          embeddings[j]
        )
      );

      matrix[i][j] = score;
      rowSum += score;
    }

    for (let j = 0; j < seqLen; j++) {
      matrix[i][j] =
        matrix[i][j] /
        (rowSum || 1);
    }
  }

  return matrix;
}

function resolveAttentions(
  modelOutput: any
): number[][][][] {
  const raw =
    modelOutput?.attentions ??
    modelOutput?.attention;

  if (raw) {
    const layers =
      tensorToArray(raw);

    return layers.map(
      (layer: any) => {
        const arr =
          tensorToArray(layer);

        if (
          Array.isArray(arr) &&
          Array.isArray(arr[0]) &&
          Array.isArray(arr[0][0]) &&
          Array.isArray(arr[0][0][0])
        ) {
          return arr[0];
        }

        return arr;
      }
    );
  }

  console.warn(
    "No real attentions. Using pseudo-attention."
  );

  const hidden =
    tensorToArray(
      modelOutput.last_hidden_state
    );

  const embeddings =
    Array.isArray(hidden?.[0]?.[0])
      ? hidden[0]
      : hidden;

  if (!embeddings?.length) {
    return [];
  }

  const matrix =
    buildPseudoAttention(
      embeddings
    );

  return [[matrix]];
}